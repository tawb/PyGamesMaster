import time
from turtle import Screen
from palyer import Player  # Ensure the file name is correct
from cars import Cars  # Ensure the file name is correct
import random
from score import Score
# Set up the screen
screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)

# Create player instance
player = Player()
score=Score()

# Car List
cars_list = []

# Keyboard control
screen.listen()
screen.onkeypress(player.moveup, "Up")
screen.onkeyrelease(player.stop, "Up")

# Game on flag
gameon = True

# Main game loop
while gameon:
    time.sleep(score.spe)
    screen.update()

    
        
    # Occasionally generate a new car
    if random.randint(1, 5) == 1:  # Adjust this to control frequency
        new_car = Cars()
        new_car.cars()
        cars_list.append(new_car)
    # Level up player if crossing threshold
    if player.ycor() > 285:
        player.level_up()
        score.score_update()
        score.update() 
        score.fast() 
        
    # Move all cars
    for car in cars_list:
        car.move()
        if player.distance(car) < 20:  # Adjust the distance threshold as needed
            score.gameover()
            gameon = False
            break 
    
       

    # Check for collision with player (this part would need logic based on player position and car)

screen.exitonclick()
