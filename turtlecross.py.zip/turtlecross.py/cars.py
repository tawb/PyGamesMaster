from turtle import Turtle
import random
COLORS= [
    "CadetBlue", "CornflowerBlue", "azure", "BlueViolet", "chartreuse", 
    "cyan", "DarkMagenta", "DeepSkyBlue", "DarkSeaGreen", "LightSkyBlue", 
    "MediumAquamarine", "PaleTurquoise", "SpringGreen", "Turquoise", 
    "DodgerBlue", "Coral", "AntiqueWhite", "DarkSlateBlue", 
    "DarkOrchid", "DeepPink"
]


class Cars(Turtle):
    def __init__(self) :
        super().__init__()
        self.shape("square")
        self.penup()
        self.shapesize(1,2)
        self.fast=10
        
        
        self.color(random.choice(COLORS))
    def move (self):
        self.backward(self.fast)
    def cars(self):
        self.goto(300,random.randrange(-280,280))
    