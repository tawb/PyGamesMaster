from turtle import Turtle 
START=(0,-275)
class Player(Turtle):
    def __init__(self) :
        super().__init__()
        self.shape("turtle")
        #self.shapesize(1.5,1.5)
        self.penup()
        self.setheading(90)
        self.goto(START)
        move=True
    def moveup(self) :
        self.move=True
        if self.move:
             self.forward(20)   
    def stop(self):
        self.move=False
    def level_up(self):
        self.goto(START)