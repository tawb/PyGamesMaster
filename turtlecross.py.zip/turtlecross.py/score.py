from turtle import Turtle 
class Score(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.hideturtle()
        self .color("black")
        self.spe=0.15
        self.goto(-250,250)
        self.score=0
        self.update()
    def update(self):
        self.clear()
        self.write(f"Level :{self.score}",align="center", font=("Georgia", 20, "normal"))
    def score_update(self):
        
        self.score+=1
    def gameover(self):
        self.goto(0,0)
        self.write(f"GAME OVER",align="center", font=("Georgia", 20, "normal"))
    def fast(self):
        self.spe*=0.7