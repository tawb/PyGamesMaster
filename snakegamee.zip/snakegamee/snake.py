from turtle import Turtle
UP=90
DOWN=270
LEFT=180
RIGHT=0
POSITIONS=[(-20,0),(-40,0),(-60,0)]
class Snake:
    def __init__(self) :
        self.snakes=[]
        self.create_snake()
        self.head=self.snakes[0]
    def move(self):
         for seg in range(len(self.snakes)-1,0,-1):
            newx=self.snakes[seg-1].xcor()
            newy=self.snakes[seg-1].ycor()
            self.snakes[seg].goto(newx,newy)
         self.head.forward(20)
    def up(self):
        if self.head.heading()!=DOWN:
            self.head.setheading(UP)
    def down(self):
         if self.head.heading()!=UP:
             self.snakes[0].setheading(DOWN)
    def left(self):
        if self.head.heading()!=RIGHT:
            self.snakes[0].setheading(LEFT)
    def right(self):
        if self.head.heading()!=LEFT:
         self.snakes[0].setheading(RIGHT)

    def create_snake(self):
        
        for POSITION in POSITIONS:
            self.add_seg(POSITION)

    def add_seg (self,POSITION) :
         segment = Turtle(shape="square")
         segment.color("white")
         segment.penup()  # Prevent drawing lines when moving
         segment.goto(POSITION )  # Set each segment's position
         self.snakes.append(segment)
    def extend(self):
        self.add_seg(self.snakes[-1].position())
    def reset(self):
        for snake in self.snakes:
            snake.goto(1000,1000)

        self.snakes.clear()
        self.create_snake()
        self.head=self.snakes[0]