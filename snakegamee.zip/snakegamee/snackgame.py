from turtle import Screen

from food import Food
from scorebored import ScoreBored
import time
from snake import Snake

screen =Screen()
screen.setup(width=600,height=600)
screen.bgcolor("black")
screen.title("My Snake Game")
screen.tracer(0)

snake=Snake()
food=Food()
score=ScoreBored()
screen.listen()
screen.onkey(snake.up,"Up")
screen.onkey(snake.down,"Down")
screen.onkey(snake.left,"Left")
screen.onkey(snake.right,"Right")
game_on=True

while game_on:
    screen.update()
    time.sleep(0.1)
    snake.move()   
#collision
    if snake.head.distance(food)<15:
        food.refresh()
        snake.extend()
        score.increse()
        

    if snake.head.xcor()>280 or snake.head.xcor()<-280 or snake.head.ycor()>280 or snake.head.ycor()<-280:
         score.reset()
         snake.reset()
        
    for seg in snake.snakes[1:]:
        if snake.head.distance(seg)<10:
            score.reset()
            snake.reset()
            
            



screen.exitonclick()