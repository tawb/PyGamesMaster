from turtle import Turtle 
class ScoreBored(Turtle):
    def __init__(self):
        super().__init__()
        self.score=0
        with open("highest_score_txt") as file:
            self.high_score = int(file.read())

        
        self.color("white")
        self.penup()
        self.goto(0,250)
        
        self.hideturtle()
        self.update()

    def update(self):
          self.clear()
          self.write(f"The score: {self.score }  The highest score :{self.high_score}", align="center", font=("Arial", 20, "normal"))
    def increse(self):
        self.score+=1  
        self.update()
    def reset(self):
         if self.score>self.high_score:
              self.high_score=self.score
              with open("highest_score_txt",mode="w") as file:
                   file.write(f"{self.high_score}")
         self.score=0
         self.update()
    #def lose(self):
        # self.goto(0,0)
        # self.write("GAME OVER",align="center",font=("Arial", 20, "normal"))
       

        
        
   
