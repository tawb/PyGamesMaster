from turtle import Turtle 
class Ball (Turtle):
    def __init__(self):
        super().__init__()
       
        self.shape("circle")
        self.shapesize(1,1)
        self.color("white")
        self.penup()
        self.goto(0,0)
        self.ymove=10
        self.xmove=10
        self.fast=0.1
    def move(self):
       
        newx=self.xcor()+self.ymove
        newy=self.ycor()+self.xmove
        self.goto(newx,newy)
        
    def bounce(self):
           self.xmove*=-1
           self.fast*=0.9
    def bounestike(self):
          
           self.ymove*=-1
           self.fast*=0.9
    def reset_ball (self)  :
         self.goto(0,0)   
         self.fast=0.1
         self.bounestike() 
           
           
       