from turtle import Turtle
class Score(Turtle):
    def __init__(self) :
        super().__init__()
        self.color("white")
        self.penup()
        self.hideturtle()
        self.leftscore=0
        self.rightscore=0
        self.update_score()
       
    def update_score(self):
        self.goto(-100,200)
        self.write(self.leftscore,align="center",font=("courier",80,"normal"))
        self.goto(100,200)
        self.write(self.rightscore,align="center",font=("courier",80,"normal"))

    def lpoint(self) :
        self.leftscore+=1
        self.clear() 
        self.update_score()  
    def rpoint(self):
        self.rightscore+=1
        self.clear() 
        self.update_score()  
