from turtle import Turtle

class Padle(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("square")
        self.shapesize(stretch_wid=5, stretch_len=1)
        self.color("white")
        self.penup()
        
        self.moving_up = False
        self.moving_down = False

    def move(self):
        if self.moving_up:
            self.goto(self.xcor(), self.ycor() + 20)
        elif self.moving_down:
            self.goto(self.xcor(), self.ycor() - 20)

    def start(self):
        self.moving_up = True

    def stop(self):
        self.moving_up = False

    def start_DOWN(self):
        self.moving_down = True

    def stop_DOWN(self):
        self.moving_down = False
