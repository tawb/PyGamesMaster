from turtle import Screen
from padle import Padle
import time
from ball import Ball
from score import Score
screen = Screen()
screen.setup(width=800, height=600)
screen.bgcolor("black")


screen.tracer(0)

# Create two paddles
stike = Padle()
stike.goto(360, 0)  # Position the first paddle on the right
stike2 = Padle()
stike2.goto(-360, 0)  # Position the second paddle on the left
ball=Ball()
score=Score()
# Key bindings for paddle 1 (stike)
screen.listen()
screen.onkeypress(stike.start, "Up")  # Start moving up when "Up" is pressed
screen.onkeyrelease(stike.stop, "Up")  # Stop moving up when "Up" is released
screen.onkeypress(stike.start_DOWN, "Down")  # Start moving down when "Down" is pressed
screen.onkeyrelease(stike.stop_DOWN, "Down")  # Stop moving down when "Down" is released

# Key bindings for paddle 2 (stike2)
screen.onkeypress(stike2.start, "w")  # Start moving up when "w" is pressed
screen.onkeyrelease(stike2.stop, "w")  # Stop moving up when "w" is released
screen.onkeypress(stike2.start_DOWN, "s")  # Start moving down when "s" is pressed
screen.onkeyrelease(stike2.stop_DOWN, "s")  # Stop moving down when "s" is released

game_on = True

while game_on:
    
    stike.move()  # Move paddle 1
    stike2.move()  # Move paddle 2
    
    screen.update()
    time.sleep(ball.fast)
    ball.move()
    if ball.ycor()>280 or  ball.ycor()<-280:
        ball.bounce()
        
    if ball.distance(stike) <50 and ball.xcor()>340 or ball.distance(stike2) <50 and ball.xcor()<-340  :
        ball.bounestike()
        
    if ball.xcor()>380 :
       ball.reset_ball()
       score.rpoint()
    if ball.xcor()<-380:
        ball.reset_ball()
        score.lpoint()
screen.exitonclick()
